package com.example.event_management_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventManagementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
