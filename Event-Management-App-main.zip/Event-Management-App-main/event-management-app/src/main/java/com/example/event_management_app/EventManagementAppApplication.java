package com.example.event_management_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventManagementAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventManagementAppApplication.class, args);
	}

}
